# Reconstructed v7.07 calculations

These are new runs of reconstructed equations, not recovered historical output.

| Dwarf | Profile | V/V_N fine | LOS fine (km/s) |
|---|---|---:|---:|
| Leo IV | Plummer | 13.979732 | 1.121858 |
| Leo IV | Tapered cusp | 13.861157 | 1.188335 |
| Pegasus III | Plummer | 19.348459 | 0.976360 |
| Pegasus III | Tapered cusp | 19.192335 | 1.032303 |
| Hydrus I | Plummer | 3.880819 | 0.594929 |
| Hydrus I | Tapered cusp | 3.422871 | 0.627331 |

## 4_polynomial
| Planet | acceleration (m/s²) | arcsec/century (16385 nodes) |
|---|---:|---:|
| Mercury | 1.496717e-08 | -149.971613 |
| Earth | 9.311972e-09 | -152.609154 |
| Saturn | 3.014456e-09 | -152.349998 |

## 5_saturated
| Planet | acceleration (m/s²) | arcsec/century (16385 nodes) |
|---|---:|---:|
| Mercury | 1.184185e-18 | -3.18480566e-08 |
| Earth | 7.902703e-18 | -3.45391814e-07 |
| Mars | 1.834649e-17 | -9.87630019e-07 |
